# odulib
# usage:
import odulib

odu.oduf()
